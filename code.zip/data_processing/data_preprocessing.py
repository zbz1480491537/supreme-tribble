import os
import numpy as np
import pickle

# data_path='../data/weibo/1h'
data_path = '../data/aps/9years'

class Data_Preprocessing(object): #将第几个文件count传入进来
    def __init__(self, params):#self是创建实例本身，里面是self的各种属性
        self.txt_file_path = os.path.join(data_path+"/1_txt_file","initial_data"+str(params["count"])+".txt")
        self.split_txt_file_path = os.path.join(data_path+"/2_split_txt_file","split_data"+str(params["count"])+".txt")
        self.encoding_txt_file_path = os.path.join("../data/input", params["dataset"], "encoding_data"+str(params["count"])+".txt")
        self.encoding_map_path = os.path.join(data_path+"/4_encoding_map","encoding_map"+str(params["count"])+".pkl")
        self.cascade_vector_map_path = os.path.join(data_path+"/5_cascade_vector_map","cascade_vectors_map"+str(params["count"])+".pkl")
        self.path_doc_topic = os.path.join("../data/output", params["dataset"],"doc_topic",
                                           params["TopicModel"]["path_doc_topic"] + str(params["count"]) + ".txt")
        self.count = params["count"]
    def split_txt_file(self):
        # 初始数据；已抽取三个文件的部分数据
        if os.path.exists(self.txt_file_path) is False:
            print("fail")
            return

        with open(self.txt_file_path, 'r') as r_file:
            for row in r_file:
                lists = row.split("\t")
                edge_information = lists[4].split(" ")
                for row_1 in edge_information:
                    edge_information_1 = row_1.split(":")
                    edge_information_1 = np.delete(edge_information_1, 2)

                    with open(self.split_txt_file_path, 'a') as w_file:  # 把拆分好的数据写入到文件中
                        w_file.write(' '.join(edge_information_1))
                        w_file.write('\n')
        print("The first step: split initial data successfully!")  # 输出的行数是155087(3200条数据)行,232854（4100条数据）行

    def new_encoding(self):
        dict_data = {}
        value = 0
        with open(self.split_txt_file_path, 'r') as r_file:
            for edges in r_file:
                edge = edges.split()
                for i in edge:
                    if i not in dict_data.keys():
                        dict_data[i] = value
                        value += 1
                # 拆分数据写入到文档中
                with open(self.encoding_txt_file_path, 'a') as e_file:
                    for each in edge:
                        e_file.write(str(dict_data[each]))
                        e_file.write(' ')
                    e_file.write('\n')
            with open(self.encoding_map_path, 'wb+') as fo:  # 将数据写入pkl文件，作为字典
                pickle.dump(dict_data, fo)
        # self.temporary()
        print("The second step: encoding data successfully!")

    def temporary(self):
        j = 0
        with open(self.split_txt_file_path, 'r') as r_file:
            for row in r_file:
                lists = row.split()
                for i in lists:
                    if j < int(i):
                        j = int(i)
        print("拆分文件"+str(self.count)+"编码前最大的值：", j)

        j = 0
        with open(self.encoding_txt_file_path, 'r') as r_file:
            for row in r_file:
                lists = row.split()
                for i in lists:
                    if j < int(i):
                        j = int(i)
        print("编码文件"+str(self.count)+"编码后最大的值：", j)


    # 将doc_topic.txt转化为（原数据：向量）的字典格式
    def node_vectors(self):
        vectors_map = {}  # 放在循环外边

        # 读取pkl的数据
        with open(self.encoding_map_path, 'rb') as r_file:
            data_map = pickle.load(r_file, encoding='bytes')

        line = 0  # 从doc_topic文件的第0行开始
        with open(self.path_doc_topic, 'r') as r_file:
            for row in r_file:
                for i in data_map.keys():  # 一个一个的取出字典中的键
                    if data_map[i] == line:  # 如果初始数据重新编码的值与doc_topic的行相同
                        vectors_map[i] = row  # 就进行赋值
                line = line + 1
        # print(vectors_map)

        with open(self.cascade_vector_map_path, 'ab') as fo:
            pickle.dump(vectors_map, fo)  # 大字典存的值是字符型的，后面赋值的时候需要更改为float型

        print("The third step: total_cascade_vectors_map.pkl successfully finished!")
