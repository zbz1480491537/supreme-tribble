# 最小二乘法合并数据

import os
import numpy as np
import pickle
import torch
import torch.nn as nn
from sklearn.preprocessing import MinMaxScaler

data_path = '../data/aps/9years'
dim = 50
class Data_integration(object):
    def __init__(self, params):
        # count是从2开始的
        self.encoding_map_path = os.path.join(data_path+"/4_encoding_map", "encoding_map" + str(1) + ".pkl")
        self.path_doc_topic = os.path.join("../data/output", params["dataset"], "doc_topic", params["TopicModel"]["path_doc_topic"] + str(1) + ".txt")
        self.path_doc_topic2 = os.path.join("../data/output", params["dataset"], "doc_topic", params["TopicModel"]["path_doc_topic"] + str(params["count"]) + ".txt")
        self.encoding_map_path2 = os.path.join(data_path+"/4_encoding_map", "encoding_map" + str(params["count"]) + ".pkl")
        self.reflect_data_path2 = os.path.join("../data/output", params["dataset"], "integration", "reflect_data"+str(params["count"]) + ".npy")
        self.reflect_data_map_path = os.path.join("../data/output", params["dataset"], "integration", "reflect_data_map" + str(1) + ".pkl")
        self.reflect_data_map_path2 = os.path.join("../data/output", params["dataset"], "integration", "reflect_data_map" + str(params["count"]) + ".pkl")
        # self.reflect_tatal_data_path = os.path.join("../data/output", params["dataset"], "integration", "reflect_total_data"+ ".npy")
        self.sharedata = 21914 #21914(aps-9years) #19738(aps-7years) #17355(aps-5years)  # 61464(weibo-1h) # the nodes of shared datas
        self.paramscount = params["count"]
        self.idmap_path = '../src/idmap.pkl'
        self.final_map2 = '../src/vector_map_all2.pkl'
        self.encoding_map_new_path= os.path.join(data_path+"/4_encoding_map",
                                                   "encoding_map_new" + str(1) + ".pkl")
        self.encoding_map_new_path2 = os.path.join(data_path+"/4_encoding_map", "encoding_map_new" + str(params["count"]) + ".pkl")

    def numpy_array(self): # 这一步也可以像reflectdata_map()一样优化
        # 将文件一转化为数组形式的字典
        vectors_map1 = {}  # 放在循环外边

        # 读取pkl的数据
        with open(self.encoding_map_path, 'rb') as r_file:
            data_map = pickle.load(r_file, encoding='bytes')

        # 将字典的键值对互换
        data_map2 = dict(zip(data_map.values(), data_map.keys()))
        with open(self.encoding_map_new_path, 'wb') as w_file:
            pickle.dump(data_map2, w_file)

        line = 0  # 从doc_topic1文件的第0行开始
        with open(self.path_doc_topic, 'r') as r_file:
            for row in r_file:
                list1 = []
                row1 = row.split(" ")
                for i in row1:
                    i = float(i)
                    list1.append(i)
                vectors_map1[data_map2[line]] = list1

                # for i in data_map.keys():  # 一个一个的取出字典中的键
                #     if data_map[i] == line:  # 如果初始数据重新编码的值与doc_topic的行相同
                #         vectors_map1[i] = list1  # 就进行赋值
                line = line + 1

        # 保存doc_topic1的数组形式的字典
        with open(self.reflect_data_map_path,'wb') as fo:
            pickle.dump(vectors_map1, fo)  # 小字典存的值为float型
        print("doc_topic1的向量矩阵字典已经完成！")
        return vectors_map1

    # 多层感知机
    def multilayerP(self):
        # 确定Y
        Y = np.zeros((self.sharedata,dim), dtype = float)
        with open(self.path_doc_topic,"r") as r_file:
            # 61464行向量
            count = 0
            for line in r_file:
                if count < self.sharedata:
                    linelist = []
                    vector = line.split(" ")
                    for i in vector:
                        i = float(i)
                        linelist.append(i)
                    Y[count,:] = linelist
                    count = count + 1
        Y = torch.from_numpy(Y).float()
        # print("Y:",Y)

        X = np.zeros((self.sharedata, dim), dtype = float)
        with open(self.path_doc_topic2, "r") as r_file:
            # 61464行向量
            count = 0
            for line in r_file:
                if count < self.sharedata:
                    linelist = []
                    vector = line.split(" ")
                    for i in vector:
                        i = float(i)
                        linelist.append(i)
                    X[count, :] = linelist
                    count = count + 1
        X = torch.from_numpy(X).float()
        # print("X:",X)

        # 获取待预测的数据
        with open(self.path_doc_topic2, "r") as r_file:
            totallines = len(r_file.readlines())  # 获取文件的行号
        with open(self.path_doc_topic2, "r") as r_file:
            test_data = np.zeros((totallines - self.sharedata, dim), dtype=float)
            num = 0
            count = 0
            for line in r_file:
                num = num + 1 #将行数移到指定的位置
                if num > self.sharedata - 1:
                    # print("num:", num)
                    if count < totallines - self.sharedata:
                        linelist = []
                        vector = line.split(" ")
                        for i in vector:
                            i = float(i)
                            linelist.append(i)
                        # print("linelist:",linelist)
                        test_data[count, :] = linelist
                        count = count + 1
        test_data = torch.from_numpy(test_data).float()

        #neural_network
        d = dim
        step_size = 0.05
        n_epochs = 50
        n_hidden = 256
        momentum = 0.9
        d_out = dim
        neural_network = nn.Sequential(
            nn.Linear(d,n_hidden),
            nn.Sigmoid(),
            nn.Linear(n_hidden,d_out),
            nn.ReLU()
        )
        loss_func = nn.MSELoss()
        optim = torch.optim.SGD(neural_network.parameters(), lr=step_size, momentum=momentum)
        print('iter, \tloss')
        for i in range(n_epochs):
            y_hat = neural_network(X)
            loss = loss_func(y_hat, Y)
            optim.zero_grad()
            loss.backward()
            optim.step()

            if i % (n_epochs // 10 ) == 0:
                print('{}, \t{:.2f}'.format(i, loss.item()))

        # print("y_hat:", y_hat)

        # 预测数据
        print("test_data:",test_data)
        predict_data = neural_network(test_data)
        print("predict_data.shape:",predict_data.shape,"\n")
        print("predict_data:",predict_data)

        # 转为numpy存储起来
        predict_data = predict_data.detach().numpy()
        np.save(self.reflect_data_path2, predict_data)

    # 获得权重矩阵，并计算映射矩阵
    def leastsqure(self):

        # 确定Y
        Y = np.zeros((self.sharedata,dim), dtype = float)
        with open(self.path_doc_topic,"r") as r_file:
            # 61464行向量
            count = 0
            for line in r_file:
                if count < self.sharedata:
                    linelist = []
                    vector = line.split(" ")
                    for i in vector:
                        i = float(i)
                        linelist.append(i)
                    Y[count,:] = linelist
                    count = count + 1
        # print("Y:",Y)

        X = np.zeros((self.sharedata, dim), dtype = float)
        with open(self.path_doc_topic2, "r") as r_file:
            # 61464行向量
            count = 0
            for line in r_file:
                if count < self.sharedata:
                    linelist = []
                    vector = line.split(" ")
                    for i in vector:
                        i = float(i)
                        linelist.append(i)
                    X[count, :] = linelist
                    count = count + 1
        # print("X", X)
        theta0 = np.ones(self.sharedata)
        X = np.c_[theta0,X] # 添加到第一列
        # print("加入了b的输入矩阵X：",X)

        # 优化
        # X2 = X.T
        # X3 = np.dot(X2, X)
        # X4 = np.linalg.inv(X3)
        # W = np.dot(np.dot(X4,X2),Y)

        W = np.asarray(np.linalg.lstsq(X,Y, rcond=None)[0])
        print("获得的权重矩阵为：", '\n', W)
        # print('the shape of W:',W.shape)

        # print("X_predict:", np.dot(X,W))
        # print("the shape of predict:",np.dot(X,W).shape)

        # 获取待映射的矩阵
        with open(self.path_doc_topic2, "r") as r_file:
            totallines = len(r_file.readlines())  # 获取文件的行号
        with open(self.path_doc_topic2, "r") as r_file:
            A2 = np.zeros((totallines - self.sharedata, dim), dtype=float)
            num = 0
            count = 0
            for line in r_file:
                num = num + 1 #将行数移到指定的位置
                if num > self.sharedata - 1:
                    # print("num:", num)
                    if count < totallines - self.sharedata:
                        linelist = []
                        vector = line.split(" ")
                        for i in vector:
                            i = float(i)
                            linelist.append(i)
                        # print("linelist:",linelist)
                        A2[count, :] = linelist
                        count = count + 1
        # print("转换前的矩阵输出为：", '\n', A2)
        # 多加一列b
        theta0_1 = np.ones(len(A2))
        A2 = np.c_[theta0_1,A2]

        A2_1 = np.dot(A2, W)  # 映射到文件一的主题中的矩阵
        print("转换后的矩阵输出为：", '\n', A2_1)
        np.save(self.reflect_data_path2, A2_1)
        # print("params:", self.paramscount)
        print("Finished reflect data!")

    # 获取其他映射后矩阵的字典——耗时比较长
    def reflectdata_map(self):
        # 加载进上一步获得的矩阵向量
        reflect_data = np.load(self.reflect_data_path2)

        vectors_map = {}
        # 根据重新编码的字典
        with open(self.encoding_map_path2, 'rb') as r_file:
            data_map = pickle.load(r_file, encoding="bytes")

        # 将字典的键值对互换
        data_map2 = dict(zip(data_map.values(), data_map.keys()))
        with open(self.encoding_map_new_path2, 'wb') as w_file:
            pickle.dump(data_map2, w_file)

        for row in range(0, reflect_data.shape[0]):
            vectors_map[data_map2[row+self.sharedata]] = reflect_data[row, :]
            # 上面一行代码是将下面的代码进行优化
            # for i in data_map.keys():
            #     if data_map[i] == row + self.sharedata:  # 如果初始数据重新编码的值与doc_topic的行相同
            #         vectors_map[i] = reflect_data[row, :]  # 就进行赋值

        # print("the length of each vector_map:",len(vectors_map))
        with open(self.reflect_data_map_path2, 'wb') as fo:  # 'w'表示只写形式，每次运行都会清零
            pickle.dump(vectors_map, fo)  # 小字典存的值为float型
        print("Finished reflect data map!")

    # 合并所有文件的字典
    def integration_map(self, vector_map_all):
        with open(self.reflect_data_map_path2,"rb") as r_file:
            vector_map = pickle.load(r_file, encoding='bytes')

        print("the length of each vector_map:",len(vector_map))
        print("vector_map_all更新前的长度:",len(vector_map_all))
        vector_map_all.update(vector_map)
        print("vector_map_all更新后的长度:",len(vector_map_all))
        return vector_map_all

    # 根据idmap.pkl文件，将大字典转化为大数组
    def map_to_numpy(self,final_map):
        # #转为hawkes需要的格式
        with open(final_map, 'rb') as r_file:
            vectors_map = pickle.load(r_file, encoding="bytes")
        print("the length of vector_map:",len(vectors_map))

        # # to save to 键值反过来的字典
        # vectors_map2 = dict(zip(vectors_map.values(), vectors_map.keys()))
        # with open(self.final_map2,'wb') as w_file:
        #     pickle.dump(vectors_map2, w_file)

        with open(self.idmap_path, 'rb') as r_file:
            idmaplist = pickle.load(r_file, encoding='bytes')
        print("the length of idmap:",len(idmaplist))

        vector_array = np.zeros((len(idmaplist), dim), dtype=float)
        # 创建一个大的numpy数组存储

        count = 0
        for key in vectors_map.keys():
            if int(key) in idmaplist:  # 因为大字典的键的个数与idmap值的个数不是全部一一对应
                i = idmaplist.index(int(key))  # 取列表的索引值
                vector_array[i, :] = vectors_map[key]  # 给数组赋值
                count = count + 1
            if count % 10000 == 0:
                print(count)
        print("vector_array:",vector_array)
        np.save('vector_array', vector_array)

    def standard_numpy(self):
        vector_array = np.load('vector_array.npy')
        data = MinMaxScaler()
        mm_vector_array = data.fit_transform(vector_array)
        print("标准化后的vector_array:",mm_vector_array)
        np.save('vector_array_standard',mm_vector_array)

