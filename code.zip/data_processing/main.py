#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import json
from data_preprocessing import Data_Preprocessing
from preprocess import PreProcess
from topic_model import GraphAnchorLDA
from data_integration import Data_integration
import pickle
import os


def load_json_file(file_path):
    with open(file_path, "r") as f:
        s = f.read()
        s = re.sub('\s', "", s)  # 正则匹配\s空格，tab健，替换为无

    params = json.loads(s)  # 将字符串转化为python对象

    print("dataset:", params["dataset"])
    return params

final_map = '..\src\\vector_map_all.pkl'

if __name__ == "__main__":
    params = load_json_file("../config.json")
    # print(params)  # 查看params的输出格式
    initialcount = params["count"]
    # dataintegration = Data_integration(params)

    #这一块可以不用运行
    # with open(os.path.join("../data/output", params["dataset"], "integration", "reflect_data_map" + str(1) + ".pkl"), "rb") as r_file:
    #         vector_map_all = pickle.load(r_file, encoding='bytes')

    while params["count"] < params["filecounts"]+1:  # 循环所有文件

        # # 第一步：拆分数据分别输入到graphstone中进行处理
        # datapreprocess = Data_Preprocessing(params)
        # datapreprocess.split_txt_file()  # 拆分数据
        # datapreprocess.new_encoding()  # 重新编码 -每次重新运行的时候，需要把原有的encoding_data删除才行

        # # GraphStone的部分
        # preprocesser = PreProcess(params)
        # preprocesser.generate_topic_concepts()
        #
        # graph_topic_model = GraphAnchorLDA(params)
        # graph_topic_model.learn_topic_distribution()  # 这一步计算了我们需要的word_topic的数据
        # graph_topic_model.calculate_node_topic_distribution()  # 这一步计算doc_topic结构向量

        # 获得（原数据对应向量)字典 -这一步是第一步的一部分
        # datapreprocess.node_vectors()
        # print("\n Very Good! You successfully finished node_vectors.")

        # 第二步：用最小二乘法/MLP合并数据
        dataintegration = Data_integration(params)
        if params["count"] == 1:
            vector_map_all = dataintegration.numpy_array()
        else:
            # 获得权重矩阵，并映射数据
            dataintegration.leastsqure()
            # dataintegration.multilayerP()

            # # 获得映射数据的字典
            dataintegration.reflectdata_map()
            #
            # # 第二步中，将doc_topic0转为数组形式的字典
            vector_map_all = dataintegration.integration_map(vector_map_all)

            if params["count"] == params["filecounts"]:
                # 保存一个大的字典
                with open(final_map, 'wb') as fo:
                    pickle.dump(vector_map_all, fo)  # 大字典存的值为float型
                # 接下来是结合idmap，转化为我们需要的数组形式
                dataintegration.map_to_numpy(final_map)
                dataintegration.standard_numpy()  # 将数组的取值范围归一化到-1-1之间

        params["count"] = params["count"] + 1
        print("主函数中的当前文件数量：", params["count"] - 1)
        # print("main中vector_map_all:",len(vector_map_all))








